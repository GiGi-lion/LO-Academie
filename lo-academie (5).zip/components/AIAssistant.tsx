import React, { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import { Course, ChatMessage } from '../types';
import { getSmartRecommendations } from '../services/geminiService';
import { Sparkles, Send, X, Bot, GraduationCap, ChevronRight, User, Target, MapPin } from 'lucide-react';

interface AIAssistantProps {
  courses: Course[];
  onSelectCourse?: (course: Course) => void;
}

// Robust Markdown Formatter Component using react-markdown
const MarkdownText: React.FC<{ text: string; isUser: boolean; courses: Course[]; onSelectCourse?: (course: Course) => void }> = ({ text, isUser, courses, onSelectCourse }) => {
  return (
    <div className="markdown-body text-sm leading-relaxed">
      <ReactMarkdown
        urlTransform={(url) => url}
        components={{
          strong: ({node, ...props}) => <strong className={isUser ? 'font-black' : 'font-bold text-slate-900'} {...props} />,
          em: ({node, ...props}) => <em className={isUser ? 'italic' : 'italic text-slate-800'} {...props} />,
          a: ({node, href, children, ...props}: any) => {
            if (!href) return <a {...props}>{children}</a>;
            
            const url = href.trim();
            
            // Extract text robustly even if children contains elements (e.g. bold tags)
            let titleText = "";
            if (Array.isArray(children)) {
               titleText = children.map(c => typeof c === 'string' ? c : c?.props?.children || '').join('');
            } else if (typeof children === 'string') {
               titleText = children;
            } else if (children && typeof children === 'object' && children.props?.children) {
               titleText = String(children.props.children);
            } else {
               titleText = String(children);
            }
            
            const isCourseLink = url.toLowerCase().startsWith('course:');
            
            let course;
            
            if (isCourseLink && courses) {
              const courseId = url.replace(/i?course:/i, '').trim();
              course = courses.find(c => String(c.id) === courseId);
              
              if (!course) {
                const searchTitle = titleText.toLowerCase().trim();
                course = courses.find(c => c.title.toLowerCase().includes(searchTitle));
              }
            }
            
            if (!course && courses && !url.startsWith('http') && !url.startsWith('mailto:')) {
               const searchTitle = titleText.toLowerCase().trim();
               if (searchTitle.length > 5) {
                 course = courses.find(c => c.title.toLowerCase().includes(searchTitle));
               }
            }

            if (course && onSelectCourse) {
              return (
                <button 
                  onClick={(e) => { 
                    e.preventDefault(); 
                    e.stopPropagation(); 
                    onSelectCourse(course!); 
                  }}
                  className={`font-bold text-left underline ${isUser ? 'text-white' : 'text-[#00C1D4] hover:text-[#0096a6] cursor-pointer'}`}
                  type="button"
                >
                  {children}
                </button>
              );
            }

            return (
              <a 
                href={href} 
                target="_blank" 
                rel="noopener noreferrer" 
                className={`underline ${isUser ? 'text-white' : 'text-blue-600 hover:text-blue-800'}`}
                {...props}
              >
                {children}
              </a>
            );
          },
          p: ({node, ...props}) => <p className="mb-2 last:mb-0" {...props} />,
          ul: ({node, ...props}) => <ul className="list-disc ml-5 mb-3 space-y-1" {...props} />,
          ol: ({node, ...props}) => <ol className="list-decimal ml-5 mb-3 space-y-1" {...props} />,
          li: ({node, ...props}) => <li className="pl-1" {...props} />,
          h3: ({node, ...props}) => <h3 className="font-bold text-sm mt-4 mb-1 uppercase tracking-wider opacity-80" {...props} />
        }}
      >
        {text}
      </ReactMarkdown>
    </div>
  );
};

// Wizard Data
const WIZARD_STEPS = [
  {
    id: 1,
    title: "Wat is je professionele rol?",
    icon: <User className="w-5 h-5" />,
    options: ["PO Docent", "VO Docent", "MBO/HBO Docent", "Student / Starter", "Anders"]
  },
  {
    id: 2,
    title: "Waarop wil je focussen?",
    icon: <Target className="w-5 h-5" />,
    options: ["Vakinhoudelijke verdieping", "Didactiek & Pedagogiek", "Persoonlijke groei", "Netwerken"]
  },
  {
    id: 3,
    title: "Wat is je voorkeur voor locatie?",
    icon: <MapPin className="w-5 h-5" />,
    options: ["Geen voorkeur", "Midden-Nederland", "Bij mij in de buurt", "Online"]
  }
];

export const AIAssistant: React.FC<AIAssistantProps> = ({ courses, onSelectCourse }) => {
  const [isOpen, setIsOpen] = useState(false);
  
  const [mode, setMode] = useState<'intro' | 'chat' | 'wizard'>('intro');
  const [wizardStep, setWizardStep] = useState(0);
  const [wizardAnswers, setWizardAnswers] = useState<string[]>([]);
  
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Reset if closed
    if (!isOpen) {
        setTimeout(() => setMode('intro'), 300);
    }
  }, [isOpen]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isOpen && mode === 'chat') scrollToBottom();
  }, [messages, isOpen, mode]);

  const startChat = () => {
    setMode('chat');
    if (messages.length === 0) {
       setMessages([{ role: 'model', text: 'Je kunt hier je vragen stellen over het actuele scholingsaanbod.' }]);
    }
  };

  const startWizard = () => {
    setMode('wizard');
    setWizardStep(0);
    setWizardAnswers([]);
  };

  const handleWizardOption = async (option: string) => {
    const newAnswers = [...wizardAnswers, option];
    setWizardAnswers(newAnswers);

    if (wizardStep < WIZARD_STEPS.length - 1) {
      setWizardStep(prev => prev + 1);
    } else {
      // Wizard Complete, Switch to Chat and Generate
      setMode('chat');
      setLoading(true);
      
      try {
        const prompt = `
          De gebruiker is een **${newAnswers[0]}** en wil focussen op **${newAnswers[1]}**.
          De voorkeur voor locatie is: **${newAnswers[2]}**.
          
          Formuleer een passend scholingsadvies op basis van het huidige aanbod.
        `;

        // Show the formulated query as a user message
        setMessages(prev => [...prev, { role: 'user', text: `Advies voor: ${newAnswers[0]}, Focus: ${newAnswers[1]}, Regio: ${newAnswers[2]}` }]);
        
        const response = await getSmartRecommendations(prompt, courses);
        setMessages(prev => [...prev, { role: 'model', text: response }]);
      } catch (error) {
        console.error("Wizard Error:", error);
        setMessages(prev => [...prev, { role: 'model', text: "Excuses, de studieadviseur is tijdelijk niet bereikbaar. Probeer het later nog eens." }]);
      } finally {
        setLoading(false);
      }
    }
  };

  const handleSend = async () => {
    if (!input.trim() || loading) return;
    const userText = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userText }]);
    setLoading(true);
    try {
      const response = await getSmartRecommendations(userText, courses);
      setMessages(prev => [...prev, { role: 'model', text: response }]);
    } catch (error) {
      console.error("Chat Error:", error);
      setMessages(prev => [...prev, { role: 'model', text: "Excuses, de studieadviseur is tijdelijk niet bereikbaar. Probeer het later nog eens." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div ref={chatContainerRef}>
      {/* Floating Action Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-6 right-6 z-[60] p-4 rounded-full shadow-2xl shadow-[#00C1D4]/30 transition-all duration-300 flex items-center gap-2
          ${isOpen ? 'rotate-90 scale-0 opacity-0' : 'rotate-0 scale-100 opacity-100'}
          bg-gradient-to-r from-[#00C1D4] to-[#0096a6] hover:scale-110 text-white cursor-pointer`}
      >
        <Sparkles className="w-6 h-6" />
        <span className="font-bold hidden md:inline">Studieadviseur</span>
      </button>

      {/* Main Container 
          - On Desktop: Bottom Right Popup
          - On Mobile: Full Screen Fixed Overlay to prevent layout issues
      */}
      <div className={`fixed z-[70] transition-all duration-500 shadow-2xl bg-white border-0 md:border border-slate-200 overflow-hidden flex flex-col
        ${isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none translate-y-20'}
        
        /* Mobile Styles */
        top-4 left-4 right-4 bottom-4 rounded-2xl
        
        /* Desktop Styles */
        md:top-auto md:left-auto md:bottom-6 md:right-6 md:w-[400px] md:h-[600px] md:max-h-[calc(100vh-48px)] md:rounded-3xl
      `}>
        
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex justify-between items-center relative overflow-hidden shrink-0">
          <div className="absolute inset-0 bg-gradient-to-r from-[#7AB800] to-[#00C1D4] opacity-90"></div>
          <div className="relative z-10 flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-xl backdrop-blur-sm">
               <Bot className="w-6 h-6 text-white" />
            </div>
            <div>
               <h3 className="font-bold text-lg leading-tight">LO Academie</h3>
               <p className="text-[10px] text-white/80 font-medium uppercase tracking-wider">
                 {mode === 'wizard' ? 'Keuzehulp' : 'Studieadviseur'}
               </p>
            </div>
          </div>
          
          {/* Close Button - Added z-50 and cursor-pointer to fix PC click issue */}
          <button 
            onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setIsOpen(false);
            }} 
            className="relative z-50 hover:bg-white/20 p-2 rounded-full transition-colors cursor-pointer"
          >
            <X className="w-6 h-6 text-white" />
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 bg-slate-50 relative overflow-hidden flex flex-col">
            
            {/* MODE: INTRO */}
            {mode === 'intro' && (
               <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center animate-in fade-in zoom-in-95 duration-300">
                  <div className="w-20 h-20 bg-white rounded-full shadow-xl mb-6 flex items-center justify-center text-[#00C1D4]">
                     <GraduationCap className="w-10 h-10" />
                  </div>
                  <h2 className="text-xl font-black text-slate-800 mb-2">Hulp nodig bij je keuze?</h2>
                  <p className="text-sm text-slate-500 mb-8 leading-relaxed">
                    Ik adviseer je graag bij het vinden van de passende bijscholing op basis van je profiel. Daarnaast kun je hier terecht voor al je vakinhoudelijke vragen.
                  </p>
                  
                  <div className="space-y-3 w-full">
                     <button 
                       onClick={startWizard}
                       className="w-full py-4 bg-[#7AB800] text-white rounded-xl font-bold shadow-lg shadow-green-500/20 hover:scale-[1.02] transition-transform flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                     >
                       <Sparkles className="w-5 h-5" /> Start Keuzehulp
                     </button>
                     <button 
                        onClick={startChat}
                        className="w-full py-4 bg-white text-slate-600 border border-slate-200 rounded-xl font-bold hover:bg-slate-50 transition-colors flex items-center justify-center gap-2"
                     >
                        Stel een vraag
                     </button>
                  </div>
               </div>
            )}

            {/* MODE: WIZARD */}
            {mode === 'wizard' && (
               <div className="absolute inset-0 p-6 flex flex-col animate-in slide-in-from-right duration-300">
                  <div className="mb-6">
                     <div className="flex gap-1 mb-4">
                        {WIZARD_STEPS.map((step, idx) => (
                           <div key={step.id} className={`h-1.5 rounded-full flex-1 transition-all duration-500 ${idx <= wizardStep ? 'bg-[#00C1D4]' : 'bg-slate-200'}`} />
                        ))}
                     </div>
                     <h2 className="text-2xl font-black text-slate-800 mb-2 flex items-center gap-3">
                       {WIZARD_STEPS[wizardStep].icon}
                       {WIZARD_STEPS[wizardStep].title}
                     </h2>
                  </div>

                  <div className="space-y-3">
                     {WIZARD_STEPS[wizardStep].options.map((option, idx) => (
                        <button
                           key={idx}
                           onClick={() => handleWizardOption(option)}
                           className="w-full text-left p-4 bg-white border border-slate-200 rounded-xl font-bold text-slate-600 hover:border-[#00C1D4] hover:text-[#00C1D4] hover:shadow-md transition-all flex justify-between items-center group"
                        >
                           {option}
                           <ChevronRight className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity text-[#00C1D4]" />
                        </button>
                     ))}
                  </div>

                  <button onClick={() => setMode('intro')} className="mt-auto text-center text-xs text-slate-400 hover:text-slate-600 font-bold py-4">
                     Annuleren
                  </button>
               </div>
            )}

            {/* MODE: CHAT */}
            {mode === 'chat' && (
               <>
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {messages.map((msg, idx) => (
                        <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2`}>
                        <div className={`max-w-[85%] p-4 rounded-2xl text-sm leading-relaxed shadow-sm ${
                            msg.role === 'user' 
                            ? 'bg-[#00C1D4] text-white rounded-tr-none font-medium' 
                            : 'bg-white border border-slate-100 text-slate-600 rounded-tl-none'
                        }`}>
                            <MarkdownText text={msg.text} isUser={msg.role === 'user'} courses={courses} onSelectCourse={onSelectCourse} />
                        </div>
                        </div>
                    ))}
                    {loading && (
                        <div className="flex justify-start">
                        <div className="bg-white border border-slate-100 p-4 rounded-2xl rounded-tl-none shadow-sm flex gap-1.5">
                            <div className="w-2 h-2 bg-[#7AB800] rounded-full animate-bounce"></div>
                            <div className="w-2 h-2 bg-[#7AB800] rounded-full animate-bounce delay-75"></div>
                            <div className="w-2 h-2 bg-[#7AB800] rounded-full animate-bounce delay-150"></div>
                        </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>

                <div className="p-4 bg-white border-t border-slate-100">
                    <div className="flex gap-2">
                        <input 
                        type="text" 
                        className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#7AB800] text-sm font-medium"
                        placeholder="Typ een bericht..."
                        value={input}
                        disabled={loading}
                        onChange={e => setInput(e.target.value)}
                        onKeyDown={e => e.key === 'Enter' && handleSend()}
                        />
                        <button 
                        onClick={handleSend}
                        disabled={loading || !input.trim()}
                        className="p-3 bg-[#7AB800] text-white rounded-xl hover:bg-[#6da500] disabled:opacity-50 transition-colors shadow-sm"
                        >
                        <Send className="w-5 h-5" />
                        </button>
                    </div>
                </div>
               </>
            )}
        </div>
      </div>
    </div>
  );
};