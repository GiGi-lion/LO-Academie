import React, { useState, useEffect } from 'react';
import { Course, sortOrganizers } from '../types';
import { MapPin, Calendar, ArrowRight, Heart, Share2, Check, Pencil, Clock } from 'lucide-react';
import { DEFAULT_IMAGES, formatPrice } from '../constants';

interface CourseCardProps {
  course: Course;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onClick: (course: Course) => void;
  isAdmin?: boolean;
  onEdit?: () => void;
}

export const CourseCard: React.FC<CourseCardProps> = ({ course, isFavorite, onToggleFavorite, onClick, isAdmin, onEdit }) => {
  const [hasError, setHasError] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  
  const isKVLO = course.organizers?.includes('KVLO');
  const isALO = course.organizers?.includes('ALO Nederland');

  useEffect(() => {
    setHasError(false);
  }, [course.imageUrl]);

  const fallbackIndex = course.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) % DEFAULT_IMAGES.length;
  const displayImage = !hasError && course.imageUrl ? course.imageUrl : DEFAULT_IMAGES[fallbackIndex];

  const handleShare = async (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    
    const shareUrl = course.url !== '#' ? course.url : window.location.href;
    const shareText = `Check deze scholing op LO Academie: ${course.title}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'LO Academie',
          text: shareText,
          url: shareUrl,
        });
        return;
      } catch (err) {
        if ((err as Error).name !== 'AbortError') console.error('Share error:', err);
      }
    }

    // Fallback: Clipboard
    try {
      const textToCopy = `${course.title}\n${shareUrl}`;
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(textToCopy);
      } else {
        const textArea = document.createElement("textarea");
        textArea.value = textToCopy;
        textArea.style.position = "fixed";
        textArea.style.left = "-9999px";
        textArea.style.top = "0";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    } catch (err) {
      console.error('Clipboard fallback failed', err);
    }
  };

  return (
    <div 
      onClick={() => onClick(course)}
      className="group bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col h-full overflow-hidden hover:-translate-y-1 relative cursor-pointer"
    >
      
      {/* Actions (Heart & Share) */}
      <div className="absolute top-4 right-4 z-40 flex gap-2">
         <button 
          onClick={handleShare}
          className={`p-2.5 rounded-full backdrop-blur-md shadow-lg transition-all ${
            isCopied ? 'bg-green-500 text-white scale-110' : 'bg-white/95 text-slate-500 hover:text-[#00C1D4] hover:scale-110'
          }`}
          title={isCopied ? "Gekopieerd!" : "Delen"}
        >
          {isCopied ? <Check className="w-5 h-5" /> : <Share2 className="w-5 h-5" />}
        </button>

        <button 
          onClick={(e) => {
            e.stopPropagation(); 
            e.preventDefault();
            onToggleFavorite(course.id);
          }}
          className="p-2.5 rounded-full bg-white/95 backdrop-blur-md shadow-lg hover:scale-110 transition-all"
        >
          <Heart 
            className={`w-5 h-5 transition-colors ${
              isFavorite ? 'fill-red-500 text-red-500' : 'text-slate-400'
            }`} 
          />
        </button>
      </div>

      {/* Admin Edit Button */}
      {isAdmin && onEdit && (
        <button 
          onClick={(e) => {
            e.stopPropagation();
            e.preventDefault();
            onEdit();
          }}
          className="absolute top-4 left-4 z-40 p-2.5 rounded-full bg-white/95 backdrop-blur-md shadow-lg text-slate-600 hover:bg-[#00C1D4] hover:text-white transition-all border border-slate-100"
          title="Scholing bewerken"
        >
          <Pencil className="w-5 h-5" />
        </button>
      )}

      <div className="relative h-48 overflow-hidden bg-slate-200">
        <img 
          src={displayImage} 
          alt={course.title} 
          onError={() => setHasError(true)}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
        
        <div className="absolute bottom-4 left-4 z-20 flex flex-wrap gap-1">
            {sortOrganizers(course.organizers).map((org, index) => {
              const orgBadgeColor = org === 'KVLO' 
                ? 'bg-[#ecfccb] text-[#4d7c0f] border-[#84cc16]' 
                : org === 'ALO Nederland' 
                  ? 'bg-[#cffafe] text-[#0891b2] border-[#06b6d4]'
                  : 'bg-[#f3e8ff] text-[#7e22ce] border-[#d8b4fe]';
              return (
              <span key={index} className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider border shadow-sm ${orgBadgeColor}`}>
                  {org}
              </span>
            )})}
        </div>
      </div>

      <div className="p-5 flex-1 flex flex-col">
        <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            {course.date && course.date.trim() !== '' ? (
              <>
                <Calendar className="w-3 h-3" />
                {new Date(course.date).toLocaleDateString('nl-NL', { day: 'numeric', month: 'short', year: 'numeric' })}
              </>
            ) : (
              <>
                <Calendar className="w-3 h-3" />
                Zonder startdatum
              </>
            )}
            {course.sessions && course.sessions > 0 && (
              <>
                <span className="mx-0.5">•</span>
                <Clock className="w-3 h-3" />
                {course.sessions} {course.sessions === 1 ? 'bijeenkomst' : 'bijeenkomsten'}
              </>
            )}
            <span className="mx-0.5">•</span>
            <MapPin className="w-3 h-3" />
            {course.location}
        </div>

        <h3 className="text-lg font-extrabold text-slate-800 mb-2 leading-tight group-hover:text-[#00C1D4] transition-colors line-clamp-2">
          {course.title}
        </h3>

        <p className="text-slate-500 text-sm mb-4 line-clamp-2 flex-1">
          {course.description}
        </p>

        <div className="mt-auto pt-4 border-t border-slate-50 flex items-center justify-between">
            {course.price === 0 ? (
              <span className="font-black text-sm px-2.5 py-1 bg-green-100 text-green-700 rounded-md uppercase tracking-wider">
                  Gratis
              </span>
            ) : course.price === undefined || course.price === null ? (
              <span className="font-bold text-sm text-slate-400 italic">
                  Kosten op aanvraag
              </span>
            ) : (
              <div className="flex items-baseline gap-2 flex-wrap">
                {isKVLO && course.memberPrice !== undefined && course.memberPrice !== null ? (
                  <>
                    <span className="font-black text-lg text-[#7AB800]">
                        {formatPrice(course.memberPrice)}
                    </span>
                    <span className="text-[10px] text-slate-400 font-bold whitespace-nowrap">
                      (niet-KVLO-leden: {formatPrice(course.price)})
                    </span>
                  </>
                ) : (
                  <span className="font-black text-lg text-[#7AB800]">
                      {formatPrice(course.price)}
                  </span>
                )}
              </div>
            )}
            <div className="flex items-center gap-1 text-xs font-bold text-[#00C1D4] group-hover:gap-2 transition-all">
                Details <ArrowRight className="w-3.5 h-3.5" />
            </div>
        </div>
      </div>
    </div>
  );
};